package com.example.termproject;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import static android.content.Context.MODE_PRIVATE;

public class EtkinlikSilDiyalog extends AppCompatDialogFragment {
    public Etkinlik etkinlik;
    public SharedPreferences mPrefs;
    public SharedPreferences.Editor prefsEditor;
    public EtkinlikTuruSecDiyalog.EtkinlikTuruSecDiyalogListener listen;
    public EtkinlikSilDiyalog(Etkinlik etk){
        this.etkinlik = etk;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder =  new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.etkinlik_sil_diyalog_layout,null);
        mPrefs = getActivity().getSharedPreferences("data", MODE_PRIVATE);
        prefsEditor = mPrefs.edit();
        builder.setView(view);
        builder.setTitle("Etkinlik Sil");
        builder.setNegativeButton("vazgeç", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        }); builder.setPositiveButton("sil", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alarmSil(etkinlik.etkinlik_id);
                etkinlikSil(etkinlik.etkinlik_id);
                Intent i = new Intent(getContext(),MainActivity.class);
                startActivity(i);
            }
        });
        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            listen = (EtkinlikTuruSecDiyalog.EtkinlikTuruSecDiyalogListener) context;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface EtkinlikSilDiyalogListener{
        void silEtkinlik();
    }
    public boolean etkinlikSil(int etkinlikId){
        Gson gson = new Gson();
        String json = mPrefs.getString("etkinlikler","");
        Type type = new TypeToken<ArrayList<Etkinlik>>(){}.getType();
        ArrayList<Etkinlik> etkinlikler = (ArrayList<Etkinlik>)gson.fromJson(json, type);
        type = new TypeToken<ArrayList<Integer>>(){}.getType();
        String json1 = mPrefs.getString("etkinlik_idler", null);
        ArrayList<Integer> etkinlikIdler = (ArrayList<Integer>)gson.fromJson(json1, type);
        int index = -1;
        for (int j=0; j<etkinlikler.size() ;j++) {
            Integer tmp = etkinlikler.get(j).etkinlik_id;
            if(tmp - etkinlikId == 0){
                index = j;
            }
        }
        if(index != -1){
            etkinlikler.remove(etkinlikler.get(index));
            etkinlikIdler.remove(etkinlikIdler.get(index));
            String json_etkinlikler = gson.toJson(etkinlikler);
            prefsEditor.putString("etkinlikler",json_etkinlikler);
            String json_idler = gson.toJson(etkinlikIdler);
            prefsEditor.putString("etkinlik_idler",json_idler);
            prefsEditor.commit();
            return true;
        }
        else {
            return false;
        }
    }
    public void alarmSil(Integer alarmId){
        Intent intent = new Intent(getContext(), AlarmReceiver.class); // eklenen etkinliklerin alarmlarının kaldırılması
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(),alarmId, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager am =(AlarmManager)getActivity().getSystemService(Activity.ALARM_SERVICE);
        am.cancel(pendingIntent);
    }
}

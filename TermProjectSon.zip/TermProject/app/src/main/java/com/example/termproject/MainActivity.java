package com.example.termproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    TextView tv ;
    public SharedPreferences mPrefs;
    public SharedPreferences.Editor prefsEditor;
    public ArrayList<Etkinlik> etkinlikler = new ArrayList<Etkinlik>();
    public ArrayList<Etkinlik> tumu = new ArrayList<Etkinlik>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Yaklaşan Etkinlikler");
        mPrefs = getSharedPreferences("data",MODE_PRIVATE);
        prefsEditor = mPrefs.edit();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.ornek_menu, menu);
        Gson gson = new Gson();
        String json = mPrefs.getString("etkinlikler","");
        Type type = new TypeToken<ArrayList<Etkinlik>>(){}.getType();
        tumu = (ArrayList<Etkinlik>)gson.fromJson(json, type);
        tumu = etkinlikleriSirala(tumu);
        etkinlikler = tumu;
        initEtkinlikler();
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1: // ayarlar
                Intent i1 = new Intent(MainActivity.this,Ayarlar.class);
                startActivity(i1);
                return true;
            case R.id.item2: // etkinlik ekle
                Intent i = new Intent(MainActivity.this,EtkinlikEkle.class);
                startActivity(i);
                return true;
            case R.id.item6: // butun etkinlikler
                etkinlikler = tumu;
                initEtkinlikler();

                return true;
            case R.id.item3: // gunluk gosterim
                etkinlikler = gunlukGosterim(tumu);
                initEtkinlikler();
                return true;
            case R.id.item4: // haftalık gosterim
                etkinlikler = haftalikGosterim(tumu);
                initEtkinlikler();
                return true;
            case R.id.item5: // aylık gosterim
                etkinlikler = aylikGosterim(tumu);
                initEtkinlikler();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void initEtkinlikler(){
        initRecyclerView();
    }
    private void initRecyclerView(){
        RecyclerView recyclerView = findViewById(R.id.recyclerv_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this,etkinlikler);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


    public ArrayList<Etkinlik> etkinlikleriSirala(ArrayList<Etkinlik> dizi){
        if(dizi !=null){
            ArrayList<Date> dateler = new ArrayList<Date>();
            for (Etkinlik i: dizi) {
                Date x = tarihOlustur(i.baslangic_tarihi_saat);
                dateler.add(x);
            }
            for(int i=0; i<dateler.size()-1; i++){
                for(int j=i+1; j<dateler.size(); j++){
                    if(dateler.get(i).after(dateler.get(j))){ // swap yap
                        Collections.swap(dateler,i,j);
                        Collections.swap(dizi,i,j);
                    }
                }
            }
            for (Etkinlik j: dizi) {
                System.err.println(j.baslangic_tarihi_saat);
            }
            return dizi;
        }
        else{
            return null;
        }
    }
    public Date tarihOlustur(String tarih){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy hh:mm");
        Date date = null;
        try {
            date = formatter.parse(tarih);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public ArrayList<Etkinlik> gunlukGosterim(ArrayList<Etkinlik> dizi){
        ArrayList<Etkinlik> etk = new ArrayList<>();
        Date y = new Date();
        for (Etkinlik i: dizi) {
            Date x = tarihOlustur(i.baslangic_tarihi_saat);
            if(x.getDate() == y.getDate()){
                etk.add(i);
            }
        }
        return etk;
    }
    public ArrayList<Etkinlik> haftalikGosterim(ArrayList<Etkinlik> dizi){
        ArrayList etk = new ArrayList();
        Date y = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(y);
        int week = cal.get(Calendar.WEEK_OF_YEAR);
        for (Etkinlik i: dizi) {
            Date x = tarihOlustur(i.baslangic_tarihi_saat);
            cal.setTime(x);
            int hafta = cal.get(Calendar.WEEK_OF_YEAR);
            if(week == hafta){
                etk.add(i);
            }
        }
        return etk;
    }
    public ArrayList<Etkinlik> aylikGosterim(ArrayList<Etkinlik> dizi){
        ArrayList etk = new ArrayList();
        Date y = new Date();
        for (Etkinlik i: dizi) {
            Date x = tarihOlustur(i.baslangic_tarihi_saat);
            if( x.getMonth() == y.getMonth()){
                etk.add(i);
            }
        }
        return etk;
    }
}

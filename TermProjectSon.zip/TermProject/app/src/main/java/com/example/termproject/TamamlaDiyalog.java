package com.example.termproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialogFragment;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import static android.content.Context.MODE_PRIVATE;

public class TamamlaDiyalog extends AppCompatDialogFragment {
    public Etkinlik yeniEtk;
    public TextView tv;
    public TamamlaDiyalogListener listen;

    public TamamlaDiyalog(Etkinlik e){
        yeniEtk = e;
    }

    public SharedPreferences mPrefs;
    public SharedPreferences.Editor prefsEditor;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        mPrefs = getActivity().getSharedPreferences("data",MODE_PRIVATE);
        prefsEditor = mPrefs.edit();
        AlertDialog.Builder builder =  new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.tamamla_layout,null);
        tv = (TextView) view.findViewById(R.id.textView5);
        builder.setView(view);
        builder.setTitle("Tamamla");
        builder.setNegativeButton("iptal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent git = new Intent(getContext(),MainActivity.class);
                startActivity(git);
            }
        }); builder.setPositiveButton("tamam", new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(DialogInterface dialog, int which) {
                listen.tamamlaEtkinlik(yeniEtk);
                // burada etkinlik shared prefle telefona kaydedilecek ve alarm olusturulacak.
                if(etkinlikSil(yeniEtk.etkinlik_id)){
                    alarmSil(yeniEtk.etkinlik_id);
                    Toast.makeText(getContext(), "Etkinlik Güncellendi", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getContext(), "Etkinlik Oluşturuldu", Toast.LENGTH_SHORT).show();
                }
                Gson gson1 = new Gson();
                String json1 = mPrefs.getString("etkinlik_idler", null);
                String json2 = mPrefs.getString("etkinlikler", "");
                ArrayList<Etkinlik> etkinlikler = (ArrayList<Etkinlik>)gson1.fromJson(json2, ArrayList.class); // etkinlikler tutulur
                ArrayList<Integer> etkinlik_idler = (ArrayList<Integer>)gson1.fromJson(json1, ArrayList.class); // etkinlik id'ler tutulur
                // burada ekleme ve alarm olursturma yapılır.
                if(etkinlikler == null || etkinlik_idler == null){
                    etkinlikler = new ArrayList<Etkinlik>();
                    etkinlik_idler = new ArrayList<Integer>();
                }
                etkinlikler.add(yeniEtk);
                etkinlik_idler.add(yeniEtk.etkinlik_id);
                String json_etkinlikler = gson1.toJson(etkinlikler);
                prefsEditor.putString("etkinlikler",json_etkinlikler);
                String json_idler = gson1.toJson(etkinlik_idler);
                prefsEditor.putString("etkinlik_idler",json_idler);
                prefsEditor.commit();
                AyarlarClass ayr = new AyarlarClass();
                String json3 = mPrefs.getString("ayarlarim", null);
                Type type = new TypeToken<AyarlarClass>(){}.getType();
                ayr = (AyarlarClass) gson1.fromJson(json3, type);
                Date alarmSaat = tarihOlustur(yeniEtk.baslangic_tarihi_saat);
                if(alarmSaat!=null){
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(alarmSaat);
                    cal.set(Calendar.SECOND,0);
                    Calendar cal2 = hatirlatmaZamaniBul(cal,yeniEtk.hatirlatma_zamani);
                    if(cal2 == null){
                        cal = hatirlatmaZamaniBul(cal,ayr.hatirlatma_zamani);
                    }
                    cal.set(Calendar.SECOND, 0);
                    cal.add(Calendar.DATE, 0);
                    Intent intent = new Intent(getContext(), AlarmReceiver.class); // AlarmCal.class'dı
                    intent.putExtra("etkinlik_id",yeniEtk.etkinlik_id);
                    intent.putExtra("etkinlik_adi",yeniEtk.etkinlik_adi);
                    intent.putExtra("etkinlik_detayi",yeniEtk.etkinlik_detayi);
                    intent.putExtra("baslangic_tarihi_saat",yeniEtk.baslangic_tarihi_saat);
                    intent.putExtra("bitis_tarihi_saat",yeniEtk.bitis_tarihi_saat);
                    intent.putExtra("yinele",yeniEtk.yinele);
                    intent.putExtra("hatirlatma_zamani",yeniEtk.hatirlatma_zamani);
                    intent.putExtra("konum",yeniEtk.konum);

                    if(ayr != null && ayr.uri_zil_sesi != null){ // yeni eklendi
                        intent.putExtra("uri_zil",ayr.uri_zil_sesi);
                    }
                    PendingIntent pendingIntent = PendingIntent.getBroadcast( getContext(),yeniEtk.etkinlik_id, intent, PendingIntent.FLAG_CANCEL_CURRENT); // getActivity yerine getBroadcast , PendingIntent.FLAG_CANCEL_CURRENT 'ti
                    AlarmManager am =(AlarmManager)getActivity().getSystemService(Activity.ALARM_SERVICE);
                     am.setExact(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis() ,pendingIntent);
                }
                Intent j = new Intent(getContext(),MainActivity.class);
                startActivity(j);
            }
        });
        return builder.create();
    }
    public interface TamamlaDiyalogListener {
        void tamamlaEtkinlik(Etkinlik etk);
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        super.onAttach(context);
        try {
            listen = (TamamlaDiyalogListener) context;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public Date tarihOlustur(String tarih){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy hh:mm");
        Date date = null;
        try {
            date = formatter.parse(tarih);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Parse edilemedi", Toast.LENGTH_SHORT).show();
        }
        return date;
    }
    public Calendar hatirlatmaZamaniBul(Calendar calendar,int secim){
        if(secim == 0){
            return calendar;
        }
        else if (secim == 1){
            calendar.add(Calendar.MINUTE,-1);
            return calendar;
        }
        else if (secim == 2){
            calendar.add(Calendar.MINUTE,-5);
            return calendar;
        }
        else if (secim == 3){
            calendar.add(Calendar.MINUTE,-10);
            return calendar;
        }
        else if (secim == 4){
            calendar.add(Calendar.MINUTE,-15);
            return calendar;
        }
        else if (secim == 5){
            calendar.add(Calendar.MINUTE,-30);
            return calendar;
        }
        else if (secim == 6){
            calendar.add(Calendar.MINUTE,-60);
            return calendar;
        }
        else if (secim == 7){
            calendar.add(Calendar.MINUTE,-120);
            return calendar;
        }
        else if (secim == 8){
            calendar.add(Calendar.HOUR,-24);
            return calendar;
        }
        else if (secim == 9){
            calendar.add(Calendar.HOUR,-48);
            return calendar;
        }
        else if (secim == 10){
            calendar.add(Calendar.DATE,-7);
            return calendar;
        }
        else{
            return null;
        }
    }
    public boolean etkinlikSil(int etkinlikId){
        Gson gson = new Gson();
        String json = mPrefs.getString("etkinlikler","");
        Type type = new TypeToken<ArrayList<Etkinlik>>(){}.getType();
        ArrayList<Etkinlik> etkinlikler = (ArrayList<Etkinlik>)gson.fromJson(json, type);
        type = new TypeToken<ArrayList<Integer>>(){}.getType();
        String json1 = mPrefs.getString("etkinlik_idler", null);
        ArrayList<Integer> etkinlikIdler = (ArrayList<Integer>)gson.fromJson(json1, type);
        if(etkinlikler == null){
            return false;
        }
        int index = -1;
        for (int j=0; j<etkinlikler.size() ;j++) {
            Integer tmp = etkinlikler.get(j).etkinlik_id;
            if(tmp - etkinlikId == 0){
                index = j;
            }
        }
        if(index != -1){
            etkinlikler.remove(etkinlikler.get(index));
            etkinlikIdler.remove(etkinlikIdler.get(index));
            String json_etkinlikler = gson.toJson(etkinlikler);
            prefsEditor.putString("etkinlikler",json_etkinlikler);
            String json_idler = gson.toJson(etkinlikIdler);
            prefsEditor.putString("etkinlik_idler",json_idler);
            prefsEditor.commit();
            return true;
        }
        else {
            return false;
        }
    }
    public void alarmSil(Integer alarmId){
        Intent intent = new Intent(getContext(), AlarmReceiver.class); // eklenen erkinliklerin alarmlarının kaldırılması// AlarmCal.classtı
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(),alarmId, intent,  PendingIntent.FLAG_CANCEL_CURRENT); // getActivity di , PendingIntent.FLAG_CANCEL_CURRENT
        AlarmManager am =(AlarmManager)getActivity().getSystemService(Activity.ALARM_SERVICE);
        am.cancel(pendingIntent);
    }
}

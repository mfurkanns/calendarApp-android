package com.example.termproject;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

public class EtkinlikTuruSecDiyalog extends AppCompatDialogFragment {
    public ImageView toplanti;
    public ImageView dogum_gunu;
    public ImageView gorev;
    public ImageView diger;
    public EtkinlikTuruSecDiyalogListener listen;
    public AlertDialog alert;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final AlertDialog.Builder builder =  new AlertDialog.Builder(getActivity());
        final LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.etkinlik_turu_sec_layout,null);
        alert = builder.create();
        toplanti = view.findViewById(R.id.imageViewToplanti);
        dogum_gunu = view.findViewById(R.id.imageViewDogumGunu);
        gorev = view.findViewById(R.id.imageViewGorev);
        diger = view.findViewById(R.id.imageViewDiger);
        builder.setView(view);
        builder.setTitle("Etkinlik Türü");

        toplanti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tur_string = "Toplantı";
                Integer tur_deger = 0;
                listen.etkilikTuruAl(tur_deger,tur_string);
                dismiss();

            }
        });
        dogum_gunu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tur_string = "Doğum günü";
                Integer tur_deger = 1;
                listen.etkilikTuruAl(tur_deger,tur_string);
                dismiss();

            }
        });
        gorev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tur_string = "Görev";
                Integer tur_deger = 2;
                listen.etkilikTuruAl(tur_deger,tur_string);
                dismiss();

            }
        });
        diger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tur_string = "Diğer";
                Integer tur_deger = 3;
                listen.etkilikTuruAl(tur_deger,tur_string);
                dismiss();

            }
        });
        return builder.create();
    }
    public interface  EtkinlikTuruSecDiyalogListener{
        void etkilikTuruAl(int etkinlikDeger,String etkinlikString);
    }
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listen = (EtkinlikTuruSecDiyalogListener) context;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

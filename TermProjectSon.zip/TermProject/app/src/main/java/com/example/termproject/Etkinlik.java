package com.example.termproject;

import android.os.Parcelable;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Etkinlik implements Comparable<Etkinlik>, Serializable {

    public Integer etkinlik_id;
    public String etkinlik_adi = "";
    public String etkinlik_detayi = "";
    public String etkinlik_turu_string = "";
    public Integer etkinlik_turu_deger;
    public String baslangic_tarihi_saat;
    public String bitis_tarihi_saat;
    public String yinele_string;
    public Integer yinele;
    public String hatirlatma_zamani_string;
    public Integer hatirlatma_zamani;
    public Double lon;
    public Double lat;
    public String konum ="";

    public void etkinlikTanit(){
        System.out.println("Etkinlik Türü = "+etkinlik_turu_string);
        System.out.println("Etkinlik id = "+etkinlik_id);
        System.out.println("Etkinlik adı = "+etkinlik_adi);
        System.out.println("Etkinlik detayı = "+etkinlik_adi);
        System.out.println("Etkinlik başlangıç saati = "+baslangic_tarihi_saat);
        System.out.println("Etkinlik bitiş saati = "+bitis_tarihi_saat);
        System.out.println("Etkinlik yineleme durumu = "+yinele);
        System.out.println("Etkinlik hatırlatma zamanı = "+hatirlatma_zamani);
        System.out.println("Etkinlik konum = "+lon+"/"+lat);
    }
    public String toString(){
        Date tarih1 = tarihOlustur(baslangic_tarihi_saat);
        Date tarih2 = tarihOlustur(bitis_tarihi_saat);
        String bilgi =  "Etkinlik Türü : "+etkinlik_turu_string+"\n"+
                        "Etkinlik Adı : "+etkinlik_adi+"\n"+
                        "Etkinlik Detayı : "+etkinlik_detayi+"\n"+
                        "Etkinlik Tarihi : "+tarih1.getDate()+"/"+tarih1.getMonth()+"/"+(tarih1.getYear()+1900)+"  "+tarih1.getHours()+":"+tarih1.getMinutes()+"\n"+
                        "Etkinlik Bitiş Zamanı : "+tarih2.getDate()+"/"+tarih2.getMonth()+"/"+(tarih2.getYear()+1900)+"  "+tarih2.getHours()+":"+tarih2.getMinutes()+"\n"+
                        "Etkinlik Adres : "+konum+"\n";
        return bilgi;
    }

    public Date tarihOlustur(String tarih){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy hh:mm");
        Date date = null;
        try {
            date = formatter.parse(tarih);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }
    @Override
    public int compareTo(Etkinlik o) {
        return 0;
    }
}

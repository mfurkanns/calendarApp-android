package com.example.termproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
public class EtkinlikGuncelle extends AppCompatActivity implements TarihSecDiyalog.TarihSecDiyalogListener, SaatSecDiyalog.SaatSecDiyalogListener,
                                                                    YineleSecDiyalog.YineleSecDiyalogListener, HatirlatmaZamaniSecDiyalog.HatirlatmaZamanSecDiyalogListener,
                                                                     TamamlaDiyalog.TamamlaDiyalogListener, VazgecDiyalog.VazgecDiyalogListener,EtkinlikTuruSecDiyalog.EtkinlikTuruSecDiyalogListener,
                                                                        EtkinlikSilDiyalog.EtkinlikSilDiyalogListener {

    public Etkinlik etkinlik;

    public int basilan;
    public int basilan_saat;

    public Integer bas_gun;
    public Integer bas_ay;
    public Integer bas_yil;
    public Integer bas_saat;
    public Integer bas_dakika;

    public Integer bit_gun;
    public Integer bit_ay;
    public Integer bit_yil;
    public Integer bit_saat;
    public Integer bit_dakika;

    public TextView bas_tv;
    public TextView bit_tv;
    public ImageView baslangic;
    public ImageView bitis;

    public TextView basSaat_tv;
    public TextView bitSaat_tv;
    public ImageView baslangicSaat;
    public ImageView bitisSaat;

    public TextView yinele;
    public ImageView yineleImage;
    public Integer yinele_deger = -1;
    public String yinele_string_deger;

    public ImageView hatirlat_zaman_Image;
    public static TextView hatirlat_zaman_tv;
    public Integer hatirlat_zaman_deger = -1;
    public String hatirlat_zaman_string_deger;

    public ImageView konum_image;
    public TextView map_tv;
    public String lokasyon_string="";
    public Double lon;
    public Double lat;

    public EditText baslik;
    public EditText detay;

    public ImageView tamamla;
    public ImageView vazgec;
    public ImageView sil;
    public ImageView gonder;

    public TextView etkinlik_turu_tv;
    public ImageView etkinlik_turu_image;
    public String etkinlik_turu_string;
    public Integer etkinlik_turu_deger;

    public String saat1;
    public String saat2;

    public SharedPreferences mPrefs;
    public SharedPreferences.Editor prefsEditor;

    public  Intent gelen_intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etkinlik_guncelle);
        this.setTitle("Etkinlik Güncelle");
        gelen_intent = getIntent();
        mPrefs = getSharedPreferences("data",MODE_PRIVATE);
        prefsEditor = mPrefs.edit();

        etkinlik_turu_tv = (TextView)findViewById(R.id.etkinlikTuru);
        etkinlik_turu_image = (ImageView)findViewById(R.id.imageViewEtkinlikTuru);
        baslik = (EditText)findViewById(R.id.editText);
        detay = (EditText)findViewById(R.id.editText2);
        tamamla = (ImageView)findViewById(R.id.imageView4);
        vazgec = (ImageView)findViewById(R.id.imageView5);
        konum_image = (ImageView)findViewById(R.id.mapImageView);
        map_tv = (TextView)findViewById(R.id.textView15);
        hatirlat_zaman_Image = (ImageView)findViewById(R.id.hatirlatImage);
        hatirlat_zaman_tv = (TextView)findViewById(R.id.textView17);
        yinele = (TextView)findViewById(R.id.textView13);
        yineleImage = (ImageView)findViewById(R.id.imageView);
        baslangic = (ImageView)findViewById(R.id.imageView2);
        bitis = (ImageView)findViewById(R.id.imageView3);
        bas_tv = (TextView)findViewById(R.id.textView7);
        bit_tv = (TextView)findViewById(R.id.textView9);
        basSaat_tv = (TextView)findViewById(R.id.saatBaslangic);
        bitSaat_tv = (TextView)findViewById(R.id.saatBitis);
        baslangicSaat = (ImageView)findViewById(R.id.saat_icon); // baslangıc saat
        bitisSaat = (ImageView)findViewById(R.id.saat_icon1);  // bitiş saat
        sil = (ImageView)findViewById(R.id.imageViewSil);
        gonder = (ImageView)findViewById(R.id.imageViewGonder);

        if(gelen_intent !=null)
        {
            int uniqid = (int)gelen_intent.getExtras().getInt("unique_id",0);
            if(uniqid == 1)
            {
                bilgileriGetir((Etkinlik) gelen_intent.getSerializableExtra("etkinlik"));
                etkinlik = (Etkinlik) gelen_intent.getSerializableExtra("etkinlik");
            }
            else{
                // haritadan ddondukten sonra ne olacak
                String adres = gelen_intent.getStringExtra("adres");
                if(adres == null){
                    map_tv.setText("");
                }
                else{
                    map_tv.setText(adres);
                    lokasyon_string = gelen_intent.getStringExtra("adres");
                    lon = gelen_intent.getDoubleExtra("lon",0.0);
                    lat = gelen_intent.getDoubleExtra("lat",0.0);
                }
            }
        }
        baslangic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan = 0;
                diyalogBaslat();
            }
        });
        bitis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan = 1;
                diyalogBaslat();
            }
        });
        baslangicSaat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan_saat = 0;
                diyalogBaslat1();
            }
        });
        bitisSaat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan_saat = 1;
                diyalogBaslat1();
            }
        });
        hatirlat_zaman_Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hatirlatmaZamanDiyalogBaslat();
            }
        });
        yineleImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                diyalogBaslat2();
            }
        });
        konum_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(EtkinlikGuncelle.this,Konum.class);
                i.putExtra("lon",lon); // burası sonradan
                i.putExtra("lat",lat); // burası sonradan
                startActivityForResult(i,11);
            }
        });
        tamamla.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Etkinlik yeni_etkinlik = new Etkinlik();
                if(bit_gun==null || bas_gun==null){
                    Toast.makeText(EtkinlikGuncelle.this, "Lütfen tarih seçiniz", Toast.LENGTH_SHORT).show();
                }
                else if (bas_saat==null || bit_saat==null){ // saat secimi yapılmalı
                    Toast.makeText(EtkinlikGuncelle.this, "Lütfen saat seçiniz", Toast.LENGTH_SHORT).show();
                }
                else{
                    Date a = new Date(bas_yil-1900,bas_ay,bas_gun,bas_saat,bas_dakika); // baslangıc tarihi ve saati
                    yeni_etkinlik.baslangic_tarihi_saat = bas_gun+"/"+bas_ay+"/"+bas_yil+" "+saat1;        ; // "2016-09-20"
                    Date b = new Date(bit_yil-1900,bit_ay,bit_gun,bit_saat,bit_dakika); // baslangıc tarihi ve saati
                    yeni_etkinlik.bitis_tarihi_saat = bit_gun+"/"+bit_ay+"/"+bit_yil+" "+saat2;

                    Date bugun = new Date();
                    bugun.setMonth(bugun.getMonth()+1);

                    if(a.after(b)){
                        Toast.makeText(EtkinlikGuncelle.this, "Başlangıç tarihi, bitiş tarihinden sonra olamaz", Toast.LENGTH_SHORT).show();
                    }
                    else if(a.before(bugun)){
                        Toast.makeText(EtkinlikGuncelle.this, "Etkinliğin başlangıcı için o gün artık geç", Toast.LENGTH_SHORT).show();
                    }
                    else if(b.before(bugun)){
                        Toast.makeText(EtkinlikGuncelle.this, "Etkinliğin bitişi için o gün artık geç", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        yeni_etkinlik.etkinlik_id = etkinlik.etkinlik_id;
                        yeni_etkinlik.etkinlik_adi = baslik.getText().toString();
                        yeni_etkinlik.etkinlik_detayi = detay.getText().toString();
                        yeni_etkinlik.yinele = yinele_deger;
                        yeni_etkinlik.hatirlatma_zamani = hatirlat_zaman_deger;
                        yeni_etkinlik.lon = lon;
                        yeni_etkinlik.lat = lat;
                        yeni_etkinlik.konum = lokasyon_string;
                        yeni_etkinlik.hatirlatma_zamani_string = hatirlat_zaman_string_deger;
                        yeni_etkinlik.yinele_string = yinele_string_deger;
                        yeni_etkinlik.etkinlik_turu_deger = etkinlik_turu_deger;
                        yeni_etkinlik.etkinlik_turu_string = etkinlik_turu_string;
                        tamamla_diyalog_baslat(yeni_etkinlik);
                    }
                }
            }
        });
        vazgec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vazgec_diyalog_baslat();
            }
        });
        sil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etkinlikSilDialogBaslat();
            }
        });
        gonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etkinlik = (Etkinlik) gelen_intent.getSerializableExtra("etkinlik");
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                if(etkinlik.lon == 0.0 && etkinlik.lat == 0.0){
                    sendIntent.putExtra(Intent.EXTRA_TEXT, etkinlik.toString());
                }
                else{
                    sendIntent.putExtra(Intent.EXTRA_TEXT, etkinlik.toString()+"\n"+"http://www.google.com/maps/place/" + etkinlik.lat+ "," + etkinlik.lon);
                }
                sendIntent.setType("text/plain");
                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });
        etkinlik_turu_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etkinlikTuruDiyalogBaslat();
            }
        });
    }
    public void etkinlikSilDialogBaslat(){
        EtkinlikSilDiyalog e = new EtkinlikSilDiyalog(etkinlik);
        e.show(getSupportFragmentManager(),"etkinlik_sil");
    }
    public void etkinlikTuruDiyalogBaslat(){
        EtkinlikTuruSecDiyalog e = new EtkinlikTuruSecDiyalog();
        e.show(getSupportFragmentManager(),"etkinlik_turu");
    }
    public void alarmSil(Integer alarmId){
        Intent intent = new Intent(this, AlarmReceiver.class); // eklenen erkinliklerin alarmlarının kaldırılması
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this,alarmId, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager am =(AlarmManager)getSystemService(Activity.ALARM_SERVICE);
        am.cancel(pendingIntent);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 11) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle b = data.getExtras();
                if (b != null) {
                    String adrs = (String) b.getSerializable("adres");
                    if(adrs!=null) {
                        lokasyon_string = adrs;
                        lon = (Double) b.getSerializable("lon");
                        lat = (Double) b.getSerializable("lat");
                        if (adrs.length() < 30) {
                            map_tv.setText(adrs);
                        } else {
                            adrs = adrs.substring(0, 20) + "...";
                            map_tv.setText(adrs);
                        }
                    }
                    else{
                        Toast.makeText(this, "İnternet bağlantınızı tekrar sağlayınız", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }
    public void vazgec_diyalog_baslat(){
        VazgecDiyalog s = new VazgecDiyalog();
        s.show(getSupportFragmentManager(),"vazgec");
    }
    public void tamamla_diyalog_baslat(Etkinlik etk){
        TamamlaDiyalog s = new TamamlaDiyalog(etk);
        s.show(getSupportFragmentManager(),"tamamla");
    }
    public void diyalogBaslat(){
        TarihSecDiyalog sec = new TarihSecDiyalog();
        sec.show(getSupportFragmentManager(),"tarih");
    }
    @Override
    public void tarihAl(int gun, int ay, int yil) {
        if(basilan==0){
            bas_ay = ay;
            bas_gun = gun;
            bas_yil = yil;
            String tarih = bas_gun+"/"+(bas_ay)+"/"+bas_yil;
            bas_tv.setText(tarih);
        }
        else if(basilan==1){
            bit_ay = ay;
            bit_gun = gun;
            bit_yil = yil;
            String tarih = bit_gun+"/"+(bit_ay)+"/"+bit_yil;
            bit_tv.setText(tarih);
        }
    }
    public void diyalogBaslat1(){
        SaatSecDiyalog s = new SaatSecDiyalog();
        s.show(getSupportFragmentManager(),"saat");
    }
    public void hatirlatmaZamanDiyalogBaslat(){
        HatirlatmaZamaniSecDiyalog d = new HatirlatmaZamaniSecDiyalog();
        d.show(getSupportFragmentManager(),"hatirlatma_zaman");
    }
    @Override
    public void saatAl(int saat, int dakika) {
        if(basilan_saat==0){ // baslangıc saati alınır alınır
            bas_saat = saat;
            bas_dakika = dakika;
            String s,s1;
            if(bas_saat<10){
                s = "0"+bas_saat;
            }
            else{
                s=bas_saat.toString();
            }
            if(bas_dakika<10){
                s1 = "0"+bas_dakika;
            }
            else{
                s1=bas_dakika.toString();
            }
            saat1 = s+":"+s1;
            basSaat_tv.setText(saat1);
        }
        else if(basilan_saat==1){ // bitiş saati alınır
            bit_saat = saat;
            bit_dakika = dakika;
            String s,s1;
            if(bit_saat<10){
                s = "0"+bit_saat;
            }
            else{
                s=bit_saat.toString();
            }
            if(bit_dakika<10){
                s1 = "0"+bit_dakika;
            }
            else{
                s1=bit_dakika.toString();
            }
            saat2 = s+":"+s1;
            bitSaat_tv.setText(saat2);
        }
    }
    public void diyalogBaslat2(){
        YineleSecDiyalog y = new YineleSecDiyalog();
        y.show(getSupportFragmentManager(),"yinele");
    }
    @Override
    public int yineleAl(int secim,String deger) {
        yinele_deger = secim;
        yinele_string_deger = deger;
        yinele.setText(deger);
        return 0;
    }
    @Override
    public void zamanAl(int secim, String deger) {
        hatirlat_zaman_deger = secim;
        hatirlat_zaman_string_deger = deger;
        hatirlat_zaman_tv.setText(deger);
    }
    @Override
    public void tamamlaEtkinlik(Etkinlik etk) {
    }
    @Override
    public void vazgec() {
        Toast.makeText(this, "Etkinlik iptal edildi", Toast.LENGTH_SHORT).show();
    }
    public void bilgileriGetir(Etkinlik etk){
        Date tarih1 = tarihOlustur(etk.baslangic_tarihi_saat);
        Date tarih2 = tarihOlustur(etk.bitis_tarihi_saat);
        bas_yil = tarih1.getYear()+1900;
        bas_ay = tarih1.getMonth()+1;
        bas_gun = tarih1.getDate();
        bas_saat = tarih1.getHours();
        bas_dakika = tarih1.getMinutes();
        bit_yil = tarih2.getYear()+1900;
        bit_ay = tarih2.getMonth()+1;
        bit_gun = tarih2.getDate();
        bit_saat = tarih2.getHours();
        bit_dakika = tarih2.getMinutes();
        etkinlik_turu_tv.setText(etk.etkinlik_turu_string);
        etkinlik_turu_deger = etk.etkinlik_turu_deger;
        etkinlik_turu_string = etk.etkinlik_turu_string;
        baslik.setText(etk.etkinlik_adi);
        detay.setText(etk.etkinlik_detayi);
        bas_tv.setText(bas_gun+"/"+(bas_ay)+"/"+bas_yil);
        bit_tv.setText(bit_gun+"/"+(bit_ay)+"/"+bit_yil);

        String s,s1;
        if(bit_saat<10){
            s = "0"+bit_saat;
        }
        else{
            s=bit_saat.toString();
        }
        if(bit_dakika<10){
            s1 = "0"+bit_dakika;
        }
        else{
            s1=bit_dakika.toString();
        }
        saat2 = s+":"+s1;
        bitSaat_tv.setText(saat2);

        String s2,s3;
        if(bas_saat<10){
            s2 = "0"+bas_saat;
        }
        else{
            s2=bas_saat.toString();
        }
        if(bas_dakika<10){
            s3 = "0"+bas_dakika;
        }
        else{
            s3=bas_dakika.toString();
        }
        saat1 = s2+":"+s3;
        basSaat_tv.setText(saat1);

        yinele.setText(etk.yinele_string);
        hatirlat_zaman_tv.setText(etk.hatirlatma_zamani_string);

        if(etk.konum == null){
            map_tv.setText("");
        }
        else{
            if(etk.konum.length()<30){
                map_tv.setText(etk.konum);
            }
            else{
                String str = etk.konum.substring(0,20)+"...";
                map_tv.setText(str);
                lokasyon_string = etk.konum;
            }
        }
        yinele_deger = etk.yinele;
        hatirlat_zaman_deger = etk.hatirlatma_zamani;
        lon = etk.lon;
        lat = etk.lat;
        lokasyon_string = etk.konum;
        hatirlat_zaman_string_deger = etk.hatirlatma_zamani_string;
        yinele_string_deger = etk.yinele_string;
    }

    public Date tarihOlustur(String tarih){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy hh:mm");
        Date date = null;
        try {
            date = formatter.parse(tarih);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }
    public boolean etkinlikSil(int etkinlikId){
        Gson gson = new Gson();
        String json = mPrefs.getString("etkinlikler","");
        Type type = new TypeToken<ArrayList<Etkinlik>>(){}.getType();
        ArrayList<Etkinlik> etkinlikler = (ArrayList<Etkinlik>)gson.fromJson(json, type);

        type = new TypeToken<ArrayList<Integer>>(){}.getType();
        String json1 = mPrefs.getString("etkinlik_idler", null);
        ArrayList<Integer> etkinlikIdler = (ArrayList<Integer>)gson.fromJson(json1, type);
        int index = -1;

        for (int j=0; j<etkinlikler.size() ;j++) {
            Integer tmp = etkinlikler.get(j).etkinlik_id;
            if(tmp - etkinlikId == 0){
                index = j;
            }
        }
        if(index != -1){
            etkinlikler.remove(etkinlikler.get(index));
            etkinlikIdler.remove(etkinlikIdler.get(index));
            String json_etkinlikler = gson.toJson(etkinlikler);
            prefsEditor.putString("etkinlikler",json_etkinlikler);
            String json_idler = gson.toJson(etkinlikIdler);
            prefsEditor.putString("etkinlik_idler",json_idler);
            prefsEditor.commit();
            return true;
        }
        else {
            return false;
        }
    }
    @Override
    public void etkilikTuruAl(int etkinlikDeger, String etkinlikString) {
        etkinlik_turu_tv.setText(etkinlikString);
        etkinlik_turu_deger = etkinlikDeger;
        etkinlik_turu_string = etkinlikString;
    }
    @Override
    public void silEtkinlik() {
    }
}

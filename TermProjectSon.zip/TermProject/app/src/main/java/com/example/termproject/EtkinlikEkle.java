package com.example.termproject;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class EtkinlikEkle extends AppCompatActivity implements TarihSecDiyalog.TarihSecDiyalogListener, SaatSecDiyalog.SaatSecDiyalogListener,
                                                                YineleSecDiyalog.YineleSecDiyalogListener, HatirlatmaZamaniSecDiyalog.HatirlatmaZamanSecDiyalogListener,
                                                                TamamlaDiyalog.TamamlaDiyalogListener, VazgecDiyalog.VazgecDiyalogListener, EtkinlikTuruSecDiyalog.EtkinlikTuruSecDiyalogListener {

    public int basilan;
    public int basilan_saat;

    public Integer bas_gun;
    public Integer bas_ay;
    public Integer bas_yil;
    public Integer bas_saat;
    public Integer bas_dakika;

    public TextView etkinlik_turu_tv;
    public ImageView etkinlik_turu_image;
    public String etkinlik_turu_string;
    public Integer etkinlik_turu_deger;


    public Integer bit_gun;
    public Integer bit_ay;
    public Integer bit_yil;
    public Integer bit_saat;
    public Integer bit_dakika;

    public TextView bas_tv;
    public TextView bit_tv;
    public ImageView baslangic;
    public ImageView bitis;

    public TextView basSaat_tv;
    public TextView bitSaat_tv;
    public ImageView baslangicSaat;
    public ImageView bitisSaat;

    public TextView yinele;
    public ImageView yineleImage;
    public Integer yinele_deger;
    public String yinele_string_deger;

    public ImageView hatirlat_zaman_Image;
    public static TextView hatirlat_zaman_tv;
    public Integer hatirlat_zaman_deger = -1;
    public String hatirlat_zaman_string_deger;

    public ImageView konum_image;
    public TextView map_tv;
    public String lokasyon_string="";
    public Double lon = 0.0;
    public Double lat = 0.0;

    public EditText baslik;
    public EditText detay;

    public ImageView tamamla;
    public ImageView vazgec;

    public String saat1;
    public String saat2;

    public SharedPreferences mPrefs;
    public SharedPreferences.Editor prefsEditor;

    private static final int LOKASYON_KOD = 99;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etkinlik_ekle);
        this.setTitle("Etkinlik Oluştur");
        checkPermission(Manifest.permission.ACCESS_FINE_LOCATION,LOKASYON_KOD);

        mPrefs = getSharedPreferences("data",MODE_PRIVATE);
        prefsEditor = mPrefs.edit();

        etkinlik_turu_tv = (TextView)findViewById(R.id.etkinlikTuru);
        etkinlik_turu_image = (ImageView)findViewById(R.id.imageViewEtkinlikTuru);
        baslik = (EditText)findViewById(R.id.editText);
        detay = (EditText)findViewById(R.id.editText2);
        tamamla = (ImageView)findViewById(R.id.imageView4);
        vazgec = (ImageView)findViewById(R.id.imageView5);
        konum_image = (ImageView)findViewById(R.id.mapImageView);
        map_tv = (TextView)findViewById(R.id.textView15);
        Intent i = getIntent();

        if(i.getStringExtra("adres")==null){
            map_tv.setText("");
        }
        else{
            if(i.getStringExtra("adres").length()<30){
                map_tv.setText(i.getStringExtra("adres"));
            }
            else{
                String str = i.getStringExtra("adres").substring(0,20)+"...";
                map_tv.setText(str);
                lokasyon_string = i.getStringExtra("adres");
                lon = i.getDoubleExtra("lon",0.0);
                lat = i.getDoubleExtra("lat",0.0);
                Log.e("a","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            }
        }
        hatirlat_zaman_Image = (ImageView)findViewById(R.id.hatirlatImage);
        hatirlat_zaman_tv = (TextView)findViewById(R.id.textView17);
        yinele = (TextView)findViewById(R.id.textView13);
        yineleImage = (ImageView)findViewById(R.id.imageView);
        baslangic = (ImageView)findViewById(R.id.imageView2);
        bitis = (ImageView)findViewById(R.id.imageView3);
        bas_tv = (TextView)findViewById(R.id.textView7);
        bit_tv = (TextView)findViewById(R.id.textView9);

        baslangic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan = 0;
                diyalogBaslat();
            }
        });
        bitis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan = 1;
                diyalogBaslat();
            }
        });
        basSaat_tv = (TextView)findViewById(R.id.saatBaslangic);
        bitSaat_tv = (TextView)findViewById(R.id.saatBitis);
        baslangicSaat = (ImageView)findViewById(R.id.saat_icon); // baslangıc saat
        bitisSaat = (ImageView)findViewById(R.id.saat_icon1);  // bitiş saat

        baslangicSaat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan_saat = 0;
                diyalogBaslat1();
            }
        });
        bitisSaat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                basilan_saat = 1;
                diyalogBaslat1();
            }
        });
        hatirlat_zaman_Image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hatirlatmaZamanDiyalogBaslat();
            }
        });
        yineleImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                diyalogBaslat2();
            }
        });

        konum_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(EtkinlikEkle.this,Konum.class);
                i.putExtra("lon",lon); // burası sonradan
                i.putExtra("lat",lat); // burası sonradan
                startActivityForResult(i,11);
            }
        });

        etkinlik_turu_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etkinlikTuruDiyalogBaslat();
            }
        });
        tamamla.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                Etkinlik yeni_etkinlik = new Etkinlik();
                if(bit_gun==null || bas_gun==null){
                    Toast.makeText(EtkinlikEkle.this, "Lütfen tarih seçiniz", Toast.LENGTH_SHORT).show();
                }
                else if (bas_saat==null || bit_saat==null){ // saat secimi yapılmalı
                    Toast.makeText(EtkinlikEkle.this, "Lütfen saat seçiniz", Toast.LENGTH_SHORT).show();
                }
                else{
                    Date a = new Date(bas_yil-1900,bas_ay,bas_gun,bas_saat,bas_dakika); // baslangıc tarihi ve saati
                    yeni_etkinlik.baslangic_tarihi_saat = bas_gun+"/"+bas_ay+"/"+bas_yil+" "+saat1;        ; // "2016-09-20"
                    Date b = new Date(bit_yil-1900,bit_ay,bit_gun,bit_saat,bit_dakika); // baslangıc tarihi ve saati
                    yeni_etkinlik.bitis_tarihi_saat = bit_gun+"/"+bit_ay+"/"+bit_yil+" "+saat2;
                    Date bugun = new Date();
                    bugun.setMonth(bugun.getMonth()+1);

                    if(a.after(b)){
                        Toast.makeText(EtkinlikEkle.this, "Başlangıç tarihi, bitiş tarihinden sonra olamaz", Toast.LENGTH_SHORT).show();
                    }
                    else if(a.before(bugun)){
                        Toast.makeText(EtkinlikEkle.this, "Etkinliğin başlangıcı için o gün artık geç", Toast.LENGTH_SHORT).show();
                    }
                    else if(b.before(bugun)){
                        Toast.makeText(EtkinlikEkle.this, "Etkinliğin bitişi için o gün artık geç", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Gson g = new Gson();
                        String json1 = mPrefs.getString("etkinlik_idler", null);
                        if(json1!=null) { // eger olusturulmus etkinlik varsa
                            ArrayList<Integer> etkinlik_idler = (ArrayList<Integer>)g.fromJson(json1, ArrayList.class); // etkinlik id'ler tutulur
                            Random rand = new Random();
                            Integer as = rand.nextInt(100000000);
                            while(etkinlik_idler.contains(a)){
                                as = rand.nextInt(100000000);
                            }
                            yeni_etkinlik.etkinlik_id = as;
                        }
                        else{
                            yeni_etkinlik.etkinlik_id = 1;
                        }
////////////////////////////////////////////////////////////////////////////////////////////////////////
                        AyarlarClass ayr = new AyarlarClass();
                        Gson gson1 = new Gson();
                        String json3 = mPrefs.getString("ayarlarim", null);
                        Type type = new TypeToken<AyarlarClass>(){}.getType();
                        ayr = (AyarlarClass) gson1.fromJson(json3, type);

                        yeni_etkinlik.etkinlik_adi = baslik.getText().toString();
                        yeni_etkinlik.etkinlik_detayi = detay.getText().toString();
                        yeni_etkinlik.lon = lon;
                        yeni_etkinlik.lat = lat;
                        yeni_etkinlik.konum = lokasyon_string;

                        if(yinele_deger == null || yinele_string_deger == null){
                            if(json3 != null && ayr.yinele != null){ // sonradan eklendi
                                yeni_etkinlik.yinele = ayr.yinele;
                                yeni_etkinlik.yinele_string = ayr.yinele_isim;
                            }
                            else{
                                yeni_etkinlik.yinele = 0;
                                yeni_etkinlik.yinele_string = "Tekrar Yok";
                            }
                        }
                        else{
                            yeni_etkinlik.yinele = yinele_deger;
                            yeni_etkinlik.yinele_string = yinele_string_deger;
                        }

                        if(hatirlat_zaman_deger == null || hatirlat_zaman_string_deger == null ){
                            if(json3 != null && ayr.hatirlatma_zamani != null){
                                yeni_etkinlik.hatirlatma_zamani = ayr.hatirlatma_zamani;
                                yeni_etkinlik.hatirlatma_zamani_string = ayr.hatirlatma_zamani_isim;
                            }
                            else{
                                yeni_etkinlik.hatirlatma_zamani = 0;
                                yeni_etkinlik.hatirlatma_zamani_string = "Etkinlik saatinde";
                            }
                        }
                        else {
                            yeni_etkinlik.hatirlatma_zamani = hatirlat_zaman_deger;
                            yeni_etkinlik.hatirlatma_zamani_string = hatirlat_zaman_string_deger;
                        }
                        yeni_etkinlik.etkinlik_turu_deger = etkinlik_turu_deger;
                        yeni_etkinlik.etkinlik_turu_string = etkinlik_turu_string;
                        tamamla_diyalog_baslat(yeni_etkinlik);
                    }
                }
            }
        });
        vazgec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vazgec_diyalog_baslat();
            }
        });
    }

    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(EtkinlikEkle.this, permission)== PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(EtkinlikEkle.this,new String[] { permission },requestCode);
        }
        else {
            Log.i("izin","Lokasyon izni vardır.");
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode == LOKASYON_KOD) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(EtkinlikEkle.this,"Lokasyon Erişim İzni Verildi",Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(EtkinlikEkle.this,"Lokasyon Erişim İzni Reddedildi",Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void etkinlikTuruDiyalogBaslat(){
        EtkinlikTuruSecDiyalog e = new EtkinlikTuruSecDiyalog();
        e.show(getSupportFragmentManager(),"etkinlik_turu");
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 11) {
            if (resultCode == Activity.RESULT_OK) {
                Bundle b = data.getExtras();
                if (b != null) {
                    String adrs = (String) b.getSerializable("adres");
                    if(adrs!=null) {
                        lokasyon_string = adrs;
                        lon = (Double) b.getSerializable("lon");
                        lat = (Double) b.getSerializable("lat");
                        if (adrs.length() < 30) {
                            map_tv.setText(adrs);
                        } else {
                            adrs = adrs.substring(0, 20) + "...";
                            map_tv.setText(adrs);
                        }
                    }
                    else{
                        Toast.makeText(this, "İnternet bağlantınızı tekrar sağlayınız", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }
    public void vazgec_diyalog_baslat(){
        VazgecDiyalog s = new VazgecDiyalog();
        s.show(getSupportFragmentManager(),"vazgec");
    }
    public void tamamla_diyalog_baslat(Etkinlik etk){
        TamamlaDiyalog s = new TamamlaDiyalog(etk);
        s.show(getSupportFragmentManager(),"tamamla");
    }
    public void diyalogBaslat(){
        TarihSecDiyalog sec = new TarihSecDiyalog();
        sec.show(getSupportFragmentManager(),"tarih");
    }
    @Override
    public void tarihAl(int gun, int ay, int yil) {
        if(basilan==0){
            bas_ay = ay;
            bas_gun = gun;
            bas_yil = yil;
            String tarih = bas_gun+"/"+(bas_ay)+"/"+bas_yil;
            bas_tv.setText(tarih);
        }
        else if(basilan==1){
            bit_ay = ay;
            bit_gun = gun;
            bit_yil = yil;
            String tarih = bit_gun+"/"+(bit_ay)+"/"+bit_yil;
            bit_tv.setText(tarih);
        }
    }
    public void diyalogBaslat1(){
        SaatSecDiyalog s = new SaatSecDiyalog();
        s.show(getSupportFragmentManager(),"saat");
    }
    public void hatirlatmaZamanDiyalogBaslat(){
        HatirlatmaZamaniSecDiyalog d = new HatirlatmaZamaniSecDiyalog();
        d.show(getSupportFragmentManager(),"hatirlatma_zaman");
    }
    @Override
    public void saatAl(int saat, int dakika) {
        if(basilan_saat==0){ // baslangıc saati alınır alınır
            bas_saat = saat;
            bas_dakika = dakika;
            String s,s1;
            if(bas_saat<10){
                s = "0"+bas_saat;
            }
            else{
                s=bas_saat.toString();
            }
            if(bas_dakika<10){
                s1 = "0"+bas_dakika;
            }
            else{
                s1=bas_dakika.toString();
            }
            saat1 = s+":"+s1;
            basSaat_tv.setText(saat1);
        }
        else if(basilan_saat==1){ // bitiş saati alınır
            bit_saat = saat;
            bit_dakika = dakika;

            String s,s1;
            if(bit_saat<10){
                s = "0"+bit_saat;
            }
            else{
                s=bit_saat.toString();
            }
            if(bit_dakika<10){
                s1 = "0"+bit_dakika;
            }
            else{
                s1=bit_dakika.toString();
            }
            saat2 = s+":"+s1;
            bitSaat_tv.setText(saat2);
        }
    }
    public void diyalogBaslat2(){
        YineleSecDiyalog y = new YineleSecDiyalog();
        y.show(getSupportFragmentManager(),"yinele");
    }
    @Override
    public int yineleAl(int secim,String deger) {
        yinele_deger = secim;
        yinele_string_deger = deger;
        yinele.setText(deger);
        return 0;
    }
    @Override
    public void zamanAl(int secim, String deger) {
        hatirlat_zaman_deger = secim;
        hatirlat_zaman_string_deger = deger;
        hatirlat_zaman_tv.setText(deger);
    }
    @Override
    public void tamamlaEtkinlik(Etkinlik etk) {
    }
    @Override
    public void vazgec() {
        Toast.makeText(this, "Etkinlik iptal edildi", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void etkilikTuruAl(int etkinlikDeger, String etkinlikString) {
        etkinlik_turu_tv.setText(etkinlikString);
        etkinlik_turu_deger = etkinlikDeger;
        etkinlik_turu_string = etkinlikString;
    }
}

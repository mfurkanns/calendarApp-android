package com.example.termproject;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private static final String TAG = "RecyclerViewAdapter";
    public ArrayList<Etkinlik> etkinlikler = new ArrayList<Etkinlik>();
    public Context mContext;

    public RecyclerViewAdapter(Context mContext,ArrayList<Etkinlik> etkinlikler) {
        this.etkinlikler = etkinlikler;
        this.mContext = mContext;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.etkinlik_gosterim_layout,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Log.d(TAG, "onBindViewHolder: cagrıldı");
        Etkinlik etk = etkinlikler.get(position);
        holder.etkinlik_adi.setText(etkinlikler.get(position).etkinlik_adi);
        holder.etkinlik_saati.setText(etkinlikler.get(position).baslangic_tarihi_saat+"                        ("+etkinlikler.get(position).yinele_string+")");
        if(etk.etkinlik_turu_deger != null){
            if(etk.etkinlik_turu_deger==0){ // toplantı
                holder.etkinlikTur.setImageResource(R.drawable.ic_group_add_black_24dp);
            }
            else if(etk.etkinlik_turu_deger==1){ // dogum gunu
                holder.etkinlikTur.setImageResource(R.drawable.ic_person_outline_black_24dp);
            }
            else if(etk.etkinlik_turu_deger==2){ // görev
                holder.etkinlikTur.setImageResource(R.drawable.ic_event_available_black_24dp);
            }
            else { // diger
                holder.etkinlikTur.setImageResource(R.drawable.ic_help_outline_black_24dp);
            }
        }
        else{
            holder.etkinlikTur.setImageResource(R.drawable.ic_help_outline_black_24dp);
        }
        holder.relative_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent i = new Intent(mContext,EtkinlikGuncelle.class);
            i.putExtra("etkinlik",etkinlikler.get(position));
            i.putExtra("unique_id",1);
            mContext.startActivity(i);
            }
        });
    }
    @Override
    public int getItemCount() {
        if(etkinlikler==null){
            return 0;
        }
        else{
            return etkinlikler.size();
        }
    }
    public  class ViewHolder extends RecyclerView.ViewHolder{
        TextView etkinlik_adi ;
        TextView etkinlik_saati;
        ImageView etkinlikTur;
        RelativeLayout relative_layout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            etkinlikTur = itemView.findViewById(R.id.etkinlikTur);
            etkinlik_adi = itemView.findViewById(R.id.etkinlikAdi);
            etkinlik_saati = itemView.findViewById(R.id.etkinlikTarih);
            relative_layout = itemView.findViewById(R.id.relative_layout);
        }
    }
}

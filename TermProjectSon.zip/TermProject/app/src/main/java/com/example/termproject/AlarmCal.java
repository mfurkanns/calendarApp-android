package com.example.termproject;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class AlarmCal extends AppCompatActivity {
    public ArrayList<Etkinlik> etkinlikler;
    public ArrayList<Integer> etkinlikIdler;
    public MediaPlayer mMediaPlayer;
    public Intent intent ;
    public TextView baslangic;
    public TextView bitis;
    public TextView adres;
    public TextView baslik_tv;
    public TextView detay_tv;
    public Etkinlik etkinlik ;
    public AyarlarClass ayarlar;
    public SharedPreferences mPrefs;
    public SharedPreferences.Editor prefsEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_alarm_cal);
        this.setTitle("Etkinlik Başladı !");
        etkinlik = new Etkinlik();
        mPrefs = getSharedPreferences("data",MODE_PRIVATE);
        prefsEditor = mPrefs.edit();

        ayarlar = new AyarlarClass();
        Gson gson1 = new Gson();
        String json2 = mPrefs.getString("ayarlarim", null);
        Type type = new TypeToken<AyarlarClass>(){}.getType();
        ayarlar = (AyarlarClass) gson1.fromJson(json2, type);
        intent = getIntent();
        int aa = intent.getIntExtra("etkinlik_id",0);
        System.out.println(aa);

        etkinlik.etkinlik_id = intent.getIntExtra("etkinlik_id",0);
        etkinlik.etkinlik_adi = intent.getStringExtra("etkinlik_adi");
        etkinlik.etkinlik_detayi = intent.getStringExtra("etkinlik_detayi");
        etkinlik.baslangic_tarihi_saat = intent.getStringExtra("baslangic_tarihi_saat");
        etkinlik.bitis_tarihi_saat = intent.getStringExtra("bitis_tarihi_saat");
        etkinlik.yinele = intent.getIntExtra("yinele",0);
        etkinlik.hatirlatma_zamani = intent.getIntExtra("hatirlatma_zamani",0);
        etkinlik.konum = intent.getStringExtra("konum");
        String baslik;

        if(etkinlik.etkinlik_adi == null){
            baslik = "";
        }
        else{
            baslik = etkinlik.etkinlik_adi;
        }
        detay_tv = (TextView)findViewById(R.id.adres3);
        baslik_tv = (TextView)findViewById(R.id.adres2);
        baslangic = (TextView)findViewById(R.id.baslangic);
        bitis = (TextView)findViewById(R.id.bitis);
        adres = (TextView)findViewById(R.id.adres);
        Date bas = tarihOlustur(etkinlik.baslangic_tarihi_saat);
        Date bit = tarihOlustur(etkinlik.bitis_tarihi_saat);
        detay_tv.setText(etkinlik.etkinlik_detayi);
        baslik_tv.setText(baslik);
        baslangic.setText(etkinlik.baslangic_tarihi_saat);
        bitis.setText(etkinlik.bitis_tarihi_saat);
        adres.setText(etkinlik.konum);
        Button stopAlarm = (Button) findViewById(R.id.button);
        stopAlarm.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                mMediaPlayer.stop();

                // aynı etkinligin tarihi guncellenmiş haliyle yeni bir etkinlik olusturulur ve aynı koddla yeni alarm olusturulur
                if(etkinlik.yinele != 0){ // yineleme var etkinlik tekrarlanacak
                    Date baslangic = tarihOlustur(etkinlik.baslangic_tarihi_saat);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(baslangic);
                    cal.set(Calendar.SECOND,0);
                    Calendar yeniTarih = yineleTarihBul(etkinlik.yinele,cal);
                    AyarlarClass ayr = new AyarlarClass();
                    Gson gson1 = new Gson();
                    String json2 = mPrefs.getString("ayarlarim", null);
                    Type type = new TypeToken<AyarlarClass>(){}.getType();
                    ayr = (AyarlarClass) gson1.fromJson(json2, type);
                    if(yeniTarih == null){ // secilmemis ozellik, ayarlardaki ozelliklerden secelim
                        yeniTarih = yineleTarihBul(ayr.yinele,cal);
                    }
                    // etkinligin saati guncellencek;
                    etkinlik.baslangic_tarihi_saat = dateToString(yeniTarih.getTime());
                    // bitiş saati guncellenecek

                    Intent intent = new Intent(AlarmCal.this, AlarmReceiver.class);

                    intent.putExtra("etkinlik_id",etkinlik.etkinlik_id);
                    intent.putExtra("etkinlik_adi",etkinlik.etkinlik_adi);
                    intent.putExtra("etkinlik_detayi",etkinlik.etkinlik_detayi);
                    intent.putExtra("baslangic_tarihi_saat",etkinlik.baslangic_tarihi_saat);
                    intent.putExtra("bitis_tarihi_saat",etkinlik.bitis_tarihi_saat);
                    intent.putExtra("yinele",etkinlik.yinele);
                    intent.putExtra("hatirlatma_zamani",etkinlik.hatirlatma_zamani);
                    intent.putExtra("konum",etkinlik.konum);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmCal.this,etkinlik.etkinlik_id, intent, PendingIntent.FLAG_CANCEL_CURRENT);
                    AlarmManager am =(AlarmManager)getSystemService(Activity.ALARM_SERVICE);
                    am.setExact(AlarmManager.RTC_WAKEUP,yeniTarih.getTimeInMillis() ,pendingIntent);
                }
                finish();
            }
        });
        if(ayarlar==null){
            playSound(this, getAlarmUri()); // burada sıkınıt olabilir
        }
        else{
            String zil_sesi_uri = ayarlar.uri_zil_sesi;
            Uri new_uri = null;
            try {
                new_uri = Uri.parse(zil_sesi_uri);
                playSound(this, new_uri); // burada sıkınıt olabilir
            } catch (Exception e) {
                e.printStackTrace();
                playSound(this, getAlarmUri());
            }
        }
    }



    private void playSound(Context context, Uri alert) {
        mMediaPlayer = new MediaPlayer();
        try {
            mMediaPlayer.setDataSource(context, alert);
            final AudioManager audioManager = (AudioManager) context
                    .getSystemService(Context.AUDIO_SERVICE);
            if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
                mMediaPlayer.prepare();
                mMediaPlayer.start();
            }
        } catch (IOException e) {
            System.out.println("OOPS");
        }
    }
    private Uri getAlarmUri() {
        Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alert == null) {
            alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (alert == null) {
                alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            }
        }
        return alert;
    }
    public Date tarihOlustur(String tarih){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy hh:mm");
        Date date = null;
        try {
            date = formatter.parse(tarih);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }
    public boolean etkinlikSil(int etkinlikId){
        Gson gson = new Gson();
        String json = mPrefs.getString("etkinlikler","");
        Type type = new TypeToken<ArrayList<Etkinlik>>(){}.getType();
        etkinlikler = (ArrayList<Etkinlik>)gson.fromJson(json, type);
        type = new TypeToken<ArrayList<Integer>>(){}.getType();
        String json1 = mPrefs.getString("etkinlik_idler", null);
        etkinlikIdler = (ArrayList<Integer>)gson.fromJson(json1, type);
        int index = -1;
        for (int j=0; j<etkinlikler.size() ;j++) {
            Integer tmp = etkinlikler.get(j).etkinlik_id;
            if(tmp - etkinlikId == 0){
                index = j;
            }
        }
        if(index != -1){
            etkinlikler.remove(etkinlikler.get(index));
            etkinlikIdler.remove(etkinlik.etkinlik_id);
            String json_etkinlikler = gson.toJson(etkinlikler);
            prefsEditor.putString("etkinlikler",json_etkinlikler);
            String json_idler = gson.toJson(etkinlikIdler);
            prefsEditor.putString("etkinlik_idler",json_idler);
            prefsEditor.commit();
            return true;
        }
        else {
            return false;
        }
    }
    public Calendar yineleTarihBul(Integer secim, Calendar tarih){
        Calendar yeniTarih = tarih;
        if(secim == 0){
            // tekrar yok
            return yeniTarih;
        }
        else if(secim == 1){ // her gün
            yeniTarih.set(Calendar.SECOND, 0);
            yeniTarih.add(Calendar.DATE, 1);
            return yeniTarih;
        }
        else if(secim == 2){ // her ay
            yeniTarih.set(Calendar.SECOND, 0);
            yeniTarih.set(Calendar.MONTH,yeniTarih.getTime().getMonth()+1);
            return yeniTarih;
        }
        else if(secim == 3){ // her yıl
            yeniTarih.set(Calendar.SECOND, 0);
            yeniTarih.add(Calendar.DATE, 0);
            yeniTarih.set(Calendar.YEAR,yeniTarih.getTime().getYear()+1+1900);
            return yeniTarih;
        }
        return null;
    }
    public String dateToString(Date date){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm");
        String tarih_string = formatter.format(date);
        return tarih_string;
    }
}
